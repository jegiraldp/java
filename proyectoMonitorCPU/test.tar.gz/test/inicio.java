
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import javax.swing.*;


public class inicio extends JFrame{
    
    static JLabel lblSaldo;
    static JTextField txtSaldo;
    static JButton btnSaldo;
    static JTextArea txtArea, txtMonitor;
    
 

     	
	public inicio(){
                /////FONDO
                Color c = new Color(255,255,255);
		getContentPane().setBackground(c);
                /////FONDO

                //Action Listener 
		//evento V = new evento();
		
		
		//Elementos
		lblSaldo = new JLabel ("Saldo:");
		lblSaldo.setBounds(20,10,50,30);
		
		txtSaldo = new JTextField(5);
		txtSaldo.setBounds(80,10,50,30);
				
		btnSaldo = new JButton ("Actualizar");
		btnSaldo.setBounds(150,10,120,30);
                
                txtArea = new JTextArea();
                txtArea.setBounds(20, 50, 350, 30);
                txtArea.setEditable(false);
                
                txtMonitor = new JTextArea();
                txtMonitor.setBounds(20, 90, 350, 400);
                txtMonitor.setEditable(false);
                
		//btnSaldo.addActionListener(V);
		
		
		//add(lblSaldo);
		//add(btnSaldo);
		//add(txtSaldo);
                add(txtArea);
                add(txtMonitor);
			
		
		setLayout(null);
		setSize(340,400);
                setTitle("cpu_myAdmin - Beta");
		setResizable(false); // con este se desactiva el boton maximizar
		//setExtendedState(MAXIMIZED_BOTH);  // con esta instrucci?n sale maximizada por defecto
		setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		setLocation(300,200);
                setVisible (true);
		
	}

	
	public static void main (String arg[]){
                            
		inicio ven = new inicio();
                new hiloImprimir("imprimir");
                new hiloReporte("reporte");
		
		
	}//main
        
        
        public static void writeArea(String texto){
        String t= "--------------------------------------------------------------------\n";   
        t+="$cpu_ma:konsole#-";
        txtArea.setText(t+texto);
        }
	
         	
         public static void writeAreaReporte(String texto){
           txtMonitor.setText(texto);
        }
	

	
	
}
