
import org.hyperic.sigar.CpuInfo;
import org.hyperic.sigar.CpuPerc;
import org.hyperic.sigar.Mem;
import org.hyperic.sigar.NetInfo;
import org.hyperic.sigar.NetInterfaceConfig;
import org.hyperic.sigar.OperatingSystem;
import org.hyperic.sigar.Sigar;
import org.hyperic.sigar.SigarException;

public class info {
    
    public static String analisis() throws SigarException{
    Sigar sigar = new Sigar();
    
        CpuInfo[] cpuInfos = sigar.getCpuInfoList();
        CpuPerc[] cpus= sigar.getCpuPercList();
        CpuInfo info = cpuInfos[0];
        Mem memoria = sigar.getMem();
        NetInterfaceConfig config = sigar.getNetInterfaceConfig(null);
        NetInfo netInfo = sigar.getNetInfo();
        
    
        OperatingSystem sys = OperatingSystem.getInstance();
        
        String retorno="";
        retorno+="Sistema:\t\t" + sys.getName()+" "+sys.getVendor();;
        //retorno+="\nVersion:\t" + sys.getVersion();
        //retorno+="\nFabricante:\t\t" + sys.getVendor();
        
        retorno+="\nMemoria Cache:\t" + info.getCacheSize();
        retorno+="\nMemoria Machine:\t" + sys.getMachine();
        
        retorno+="\nProcesador:\t\t"+info.getVendor()+" "+ info.getMhz()+" Mhz";
        retorno+="\nCPU Uso:\t\t" + CpuPerc.format(cpus[0].getUser());
        retorno+="\nCPU Idle:\t\t" + CpuPerc.format(cpus[0].getIdle());
        
        retorno+="\nMemoria Total:\t" + (float)memoria.getRam()/1024;
        retorno+="\nMemoria Usada:\t" + (float)memoria.getUsed()/1024;
        retorno+="\nMemoria Libre:\t" + (float)memoria.getFree()/1024;
        
        retorno+="\nRed-Ip:\t\t" + config.getAddress();
        retorno+="\nMAC:\t\t" + config.getHwaddr();
        retorno+="\nNombre:\t\t" + netInfo.getHostName();
        
        
        
        
        
        return retorno;
        
    
    }
    
}
