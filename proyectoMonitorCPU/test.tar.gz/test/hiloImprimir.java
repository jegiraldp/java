import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class hiloImprimir extends Thread{
 
    static Calendar c;
    
    public hiloImprimir(String n){
        setName(n);
        start();
    
    }
    
    public void run(){
        String h;
        
        for (int i = 0; i < 3600; i++) {
               
        c = Calendar.getInstance();
            
        //h=String.valueOf(c.get(Calendar.YEAR)+"-"+(Calendar.MONTH)+1+"-"+Calendar.DAY_OF_MONTH);
        h="-"+String.valueOf(c.get(Calendar.HOUR_OF_DAY));
        h+=":"+String.valueOf(c.get(Calendar.MINUTE));
        h+=":"+String.valueOf(c.get(Calendar.SECOND));
        
        
        inicio.writeArea(h);
            try {    
                sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(hiloImprimir.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }               
    }//main
}//hilo
    
