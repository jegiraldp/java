import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hyperic.sigar.SigarException;

public class hiloReporte extends Thread{
 
    static Calendar c;
    
    public hiloReporte(String n){
        setName(n);
        start();
    
    }
    
    public void run(){
        String h;
        
        for (int i = 0; i < 3600; i++) {
               
            try {
                inicio.writeAreaReporte(info.analisis());
            } catch (SigarException ex) {
                Logger.getLogger(hiloReporte.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {    
                sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(hiloImprimir.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }               
    }//main
}//hilo
