public class uno{
public static void main(String[] arg){
System.out.println("hi");
}
}
